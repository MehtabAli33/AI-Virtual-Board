import Razorpay from "razorpay";

const razorpay = new Razorpay({
  key_id: "rzp_test_2nFoeUFeOXBMIC",
  key_secret: "aSqIlgl1SoTTND0xbhq3LSGa",
});

export default razorpay;
